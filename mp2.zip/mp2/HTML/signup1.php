<?php
include("connection.php");
error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="UTF-8">
        <script>
            function login(){
                window.location = 'login1.php';
            }
        </script>
        <title>
            Sign up
        </title>
        <style>
            BODY{
                margin: 0;
                padding: 0;
                font-family: sans-serif; 
            }
            *{
                box-sizing: border-box; 
            }
            .container{
                width: 600px;
                padding: 40px;
                position: absolute;
                top: 60%;
                left: 50%;
                transform: translate(-50%,-50%);
                background:#191919;
                text-align: center;
                color:white;
    text-transform: uppercase;
    font-weight: 200;
            }
            input[type=text],input[type=email],input[type=password]{
                border: 0;
                background: none;
                display: block;
                margin: 20px auto;
                text-align: center;
                border: 2px solid #0367fd;
                padding: 14px 10px;
                width: 200px;
                outline: none;
                color: white;
                border-radius: 24px;
                transition: 0.25px;
            }
            input[type=text]:focus,input[type=email]:focus,input[type=password]:focus{
                width: 280px;
                border-color: #2ecc71;
            }
            .registerbtn{
                border: 0;
                background: none;
                display: block;
                margin: 20px auto;
                text-align: center;
                border: 2px solid #ffc400ec;
                padding: 14px 40px;
                outline: none;
                color: white;
                border-radius: 24px;
                transition: 0.25px;
                cursor: pointer;
            }
            .registerbtn:hover{
                background: #ffc400ec;
            }
            #button
            {
                border: 0;
                background: none;
                display: block;
                margin: 20px auto;
                text-align: center;
                border: 2px solid #ffc400ec;
                padding: 14px 40px;
                outline: none;
                color: white;
                border-radius: 24px;
                transition: 0.25px;
                cursor: pointer;
            }
            a{
                color: blue;
            }
            .login{
                background: whitesmoke;
                text-align: centre;
            }
        </style>
    </head>
    <body>
        <div class="container">
        <form class="box" action="" method="post">
        <form class="box" action="signup1.php" method="post">
            <h1>Sign up</h1>
            <p>Enter your details</p>
            <input type="text" id="name" placeholder="Name" name="name"required>
            <input type="email" id="email" placeholder="Email" name="email" required>
            <input type="password" id="psw" placeholder="Password" name="password" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 and atmost 16 characters and no spaces" required>
            <input type="password" id="rpsw" placeholder="Re-password" name="repassword" required>
            <ul>
                <p>By creating an account you agree to our</p><a href="https://www.google.com/">Terms and Privacy</a>
            </ul>
             <tr>
                 <td><input type="submit" id="button" name="submit"></td>
             </tr>
            <p>Already have account?</p>
            <button class="registerbtn" onclick="login()">Login</button>
            </form>
        </form>
       </div>
    </body>
</html>

<?php
date_default_timezone_set("Asia/Hyderabad");
if(isset($_POST['submit']))
{
$nm=$_POST['name'];
$em=$_POST['email'];
$psw=$_POST['password'];
$rpsw=$_POST['repassword'];
if($nm!="" && $em!="" && $psw!="" && $rpsw!="")
{
//echo "$nm";
//echo "$em";
//echo "$psw";
//echo "$rpsw";
    $query1 = "select * from signup where email='$em'";
    $data1 = mysqli_query($conn,$query1);
    $total= mysqli_num_rows($data1);
    if($total)
    {
        echo '<script>alert("Email already exists")</script>';
    }
    else
    {
        $uppercase = preg_match('@[A-Z]@', $psw);
        $lowercase = preg_match('@[a-z]@', $psw);
        $number    = preg_match('@[0-9]@', $psw);
        $specialChars = preg_match('@[^\w]@', $psw);
        $spaces = preg_match(' ', $psw);

        if(!$uppercase || !$lowercase || !$number || !$specialChars || strlen($psw) < 8 || strlen($psw)>16 || $spaces)
        {
            echo '<script>alert("Invalid passowrd format")</script>';
        }
        else
        {
        if($rpsw!=$psw)
        {
            echo '<script>alert("Password dose not match re-password")</script>';
        }
        else{
            $activationcode=md5($em.time());
            $status=0;
            $ciphering= "AES-128-CTR";
            $option=0;
            $encription_iv= '12345678901234567';
            $encription_key= "sakethkrishnamanoj";
            $epass= openssl_encrypt($psw,$ciphering,$encription_key,$option,$encription_iv);
        $query="INSERT INTO SIGNUP VALUES ('$nm','$em','$epass','$activationcode','$status')";
        $data=mysqli_query($conn,$query);
        if($data){
            $to=$em;
            $msg="Thank you for registering";
            $subject="Email verification";
            $headers.= "MIME-Version: 1.0"."\r\n";
            $headers.='Content-type: text/html; charset=iso-8859-1'."\r\n";
            $headers.='From:Startup/AngelInvesto | <sakethsai000@gmail.com>'."\r\n";
            
            $msg.="<html></body><div><div>Dear $nm,</div></br></br>";
            $msg.="<div style='padding-top:8px;'>Please click the following link for
            verifying and activating your account</div>
            <div style='padding-top:10px;'><a
            href='http://localhost/mp2/HTML/email_verification.php?code=$activationcode'>Click Here</a></div>
            <div style='padding-top:4px;'>Powered by <a
            href='http://localhost/mp2/HTML/signup1.php'>Startup/AngelInvesto</a></div></div>
            </body></html>";
            if(mail($to,$subject,$msg,$headers)){
            echo "<script>alert('Registration successful, please verify in the registered email-id');</script>";
            echo "<script>window.location= 'login1.php';</script>";
            }
            else{
                echo "email not send";
            }
        }
        else{
        echo '<script>alert("Signup unsuccessfull")</script>';
        }
        }
        }
    }
}
else{
   echo '<script>alert("Please fill all the fields")</script>';
}
}
?>
