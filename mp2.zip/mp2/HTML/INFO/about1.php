<?php
$servername="localhost";
$username="root";
$password="";
$dbname="mini_project2";

$conn=mysqli_connect($servername,$username,$password,$dbname);

if($conn)
{
    //echo "connection done";
}
else{
    echo "Connection Failed".mysqli_connect_error();
}
error_reporting(0);
session_start();
if(!isset($_SESSION['logged']))
{
	header('Location: /mp2/HTML/Error.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" href="style.css" type="text/css">

	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script> 

</head>
<body>
	<div class="con">
		<div class="navv"><nav><a href="../index.php" style="color:white;">HOME</nav></a></nav></div>
		<br>
		<h1 class="text-white bg-dark text-center">
			About Page
		</h1>
		<h2 style="color: white;"><u>Entreprenuer</u></h2>
		<form method="post" enctype="multipart/form-data">
			<div class="fg">
				<label for="user">Name: </label>
				<input type="text" name="name" id="user" class="fc" required>
			</div>
			<div class="fg">
				<label for="user">Field: </label>
				<input type="text" name="field" id="user" class="fc" required>
			</div>
			<div class="fg">
				<label for="user">Birth of Date: </label>
				<input type="date" name="age" id="user" class="fc" required>
			</div>
			<div class="fg">
				<label for="user">Current Status: </label>
				<input type="text" name="prevproj" id="user" class="fc" required>
			</div>
			<div class="fg">
				<p>Gender: 
				<label for="user">Male </label>
				<input type="radio" name="gender" id="user" class="fc" value="Male">
				<label for="user">Female </label>
				<input type="radio" name="gender" id="user" class="fc" value="Femail">
			</p>
			</div>
			<div class="fg">
				<p>Additional Information: </p>
				<textarea name="paragraph_text" cols="50" rows="5" required></textarea>
			</div>
			
			<div class="but">
			<input type="submit" name="submit" value="Submit" class="btn btn-success">
			</div>
		</form>
	</div>
</body>
</html>
<?php
if(isset($_POST['submit']))
{
$em=$_SESSION['email'];
$nm=$_POST['name'];
$field=$_POST['field'];
$dob=$_POST['age'];
$pprj=$_POST['prevproj'];
$gen=$_POST['gender'];
$adinfo=$_POST['paragraph_text'];
$query1 = "select * from investor where email='$em'";
$data1 = mysqli_query($conn,$query1);
$total= mysqli_num_rows($data1);
$query2 = "select * from entreprenuer where email='$em'";
$data2 = mysqli_query($conn,$query2);
$total1= mysqli_num_rows($data2);
if($total || $total1)
    {
        echo '<script>alert("Your details already exists")</script>';
    }
else{
		$query="INSERT INTO entreprenuer VALUES ('$em','$nm','$field','$dob','$pprj','$gen','$adinfo')";
		$data=mysqli_query($conn,$query);
		if($data)
		{
			echo '<script>alert("Data entered successfuly")</script>';
		}
		else{
			echo '<script>alert("Data not entered")</script>';
		}
	}
}
