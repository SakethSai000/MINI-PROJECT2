<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" href="style1.css" type="text/css">
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script> 
</head>
<body>
	<div class="spac">
		<h1>Which one are you?</h1>
			<div class="sp1">
				<a href="about.php"><img src="inve.png" style="width: 238px; height: 238px;"></a>
				<h3>Investor</h3>
			</div>
			<div class="sp1">
				<a href="about1.php"><img src="entre.jpg" style="width: 233px; height: 233px;"></a>
				<h3>Entreprenuer</h3>
			</div>
	</div>

</body>
</html>