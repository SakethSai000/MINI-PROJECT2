function register(){
const signUp = e => {
    let name = document.getElementById('name').value,
        email = document.getElementById('email').value,
        psw = document.getElementById('psw').value,
        rpsw = document.getElementById('rpsw').value;

    let formData = JSON.parse(localStorage.getItem('formData')) || [];

    let exist = formData.length && 
        JSON.parse(localStorage.getItem('formData')).some(data => 
            data.name.toLowerCase() == name.toLowerCase() && 
            data.email.toLowerCase() == email.toLowerCase()
        );

    if(!exist){
        formData.push({ name, email, psw, rpsw });
        localStorage.setItem('formData', JSON.stringify(formData));
        document.querySelector('form').reset();
        document.getElementById('name').focus();
        alert("Account Created.\n\nPlease Sign In using the link below.");
    }
    else{
        alert("Ooopppssss... Duplicate found!!!\nYou have already sigjned up");
    }
    e.preventDefault();
}
}