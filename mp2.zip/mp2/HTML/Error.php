<?php
echo "ERROR: PLEASE LOGIN TO ACCES THIS PAGE";
echo '<li><a href="signup1.php">LOGIN</a></li>';
?>