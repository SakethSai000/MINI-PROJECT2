<?php
session_start();
if(!isset($_SESSION['logged']))
{
	header('Location: /mp2/HTML/Error.php');
}
include("../details.php");
include("../connection.php");
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" href="style.css">
	<style>
			.pro1{
    text-align: center;
     margin: auto;
  width: 50%;
  border: 3px solid green;
  padding: 10px;
  font-size: 20px;
}
.pro1 p:hover{
    font-size: 25px;
    color: red;
}
	</style>
</head>
<body>
	<?php
	$query1="select * from entreprenuer where email='$decryption'";
	$data1=mysqli_query($conn,$query1);
	$result=mysqli_fetch_assoc($data1);
	echo '<div class="pro1">
		<h1>Entreprenuer</h1>
		<br>
		<img src="ent1.jpg" style="width:100%">
		<br>
		<p style="font-size: 20px;">Name: ';echo $result['name'];echo '</p>
		<br>
		<p style="font-size: 20px;">Date of Birth: ';echo $result['dob'];echo '</p>
		<br>
		<p style="font-size: 20px;">Field: ';echo $result['field'];echo '</p>
		<br>
		<p style="font-size: 20px;">Status: ';echo $result['status'];echo '</p>
		<br>
		<p style="font-size: 20px;">Gender: ';echo $result['gender'];echo '</p>
		<br>
		<p style="font-size: 20px;">Email: ';echo $result['email'];echo '</p>
		<br>
		<p style="font-size: 20px";>Additional Information: ';echo $result['addinfo'];echo '</p>
		<br>
		<p>**To proceed further can contact the above given email Id.**</p>
	</div>';
	?>
</body>
</html>