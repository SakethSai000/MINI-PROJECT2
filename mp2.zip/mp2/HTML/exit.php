<?php
session_start();
if(session_destroy())
{
    header('Location: /mp2/HTML/signup1.php');
}
?>