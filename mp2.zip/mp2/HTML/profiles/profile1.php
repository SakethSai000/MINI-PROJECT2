<?php
include("../details.php");
    if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS']==='on'){
    $url="http://";
    }else{
    $url="http://";
    $url.=$_SERVER['HTTP_HOST'];
    $url.=$_SERVER['REQUEST_URI'];
    $url;
    }
$page=$url;
//$sec="5";
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="refresh" content="<?php echo ''; ?>" URL="
        <?php echo $page; ?>">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" integrity="sha384-jLKHWM3JRmfMU0A5x5AkjWkw/EYfGUAGagvnfryNV3F9VqM98XiIH7VBGVoxVSc7" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
		<h1 style="text-align:center">Welcome</h1>
		<section>
		 <?php
                     $servername="localhost";
                     $username="root";
                     $password="";
                     $dbname="mini_project2";
                     
                     $conn=mysqli_connect($servername,$username,$password,$dbname);
                     
                     if($conn)
                     {
                         //echo "connection done";
                     }
                     else{
                         echo "Connection Failed".mysqli_connect_error();
                     }
                     error_reporting(0);
                     $query1="select * from investor where email='$decryption'";
                     $data1=mysqli_query($conn,$query1);
                     $i=1;
                while($result=mysqli_fetch_assoc($data1)){
                    if($result['email']!=$_SESSION['email']){
                echo '<div class="r1">
                    <div class="cp">
                        <h1 style="text-align:center">Investor '; echo $result['name'];echo '</h1>
                        <br>
                        <br>
                        <div style="text-align:center"><img src="p2.jpg"></div>
                        <br>
                        <p style="text-align:center; font-size:150%; text-decoration: underline; font-weight:bold;">Details</p>
                        <p style="width:20px; height:20px;">
                        <p style="text-align:center; font-size:150%;">Name:  ';echo $result['name'];
                        echo '<br><br>Field:  ';echo $result['field'];
                        echo '<br><br>Date of Birth:  ';echo $result['dob'];
                        echo '<br><br>Email:  ';echo $result['email'];
                        echo '<br><br>Budget:  ';echo $result['budget'];
                        echo '<br><br>Previous Project:  ';echo $result['prevproj'];
                        //echo '<br><br>Status:  ';echo $result['status'];
                        echo '<br><br>Additional Information:  ';echo $result['addinfo'];
                        echo '<br><br>Gender:  ';echo $result['gender']; echo'</p>
                        </p>
                        <br>
                        <br>
                        <p style="text-align:center; font-size:150%;">**To proceed further can contact the above given email Id.**</p>
                    </div>';
                    $i++;
                 }
                }
                  
            ?>
                </section>
</body>
</html>