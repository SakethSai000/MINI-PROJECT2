<?php
    if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS']==='on'){
    $url="http://";
    }else{
    $url="http://";
    $url.=$_SERVER['HTTP_HOST'];
    $url.=$_SERVER['REQUEST_URI'];
    $url;
    }
$page=$url;
$sec="5";
session_start();
if(!isset($_SESSION['logged']))
{
	header('Location: /mp2/HTML/Error.php');
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="refresh" content="<?php echo $sec; ?>" URL="
        <?php echo $page; ?>">
        <meta name="viewport" content="with=device-width, initial-scale=1.0">
        <meta charset="utf-8">

        <title>STARTUP-ANGELIVESTO</title>
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" integrity="sha384-jLKHWM3JRmfMU0A5x5AkjWkw/EYfGUAGagvnfryNV3F9VqM98XiIH7VBGVoxVSc7" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
        <!-- Home -->
            <section class="inve-header">
                <!-- <img src="backgro.png" alt="Trulli" width="500" height="333"> -->
                <nav>
                    <a href="Index.php"><img src="logo.jpg" style="height:50%"></a>
                    <div class="nav-links" id="nL">
                        <i class="fa fa-times" onclick="hidemenu()"></i>
                        <ul>
                            <li><a href="Index.php">HOME</a></li>
                            <li><a href="entreprenuer1.php">ENTREPRENEUR</a></li>
                            <li><a href="investor1.php">INVESTOR</a></li>
                            <li><a href="INFO/select.php">ABOUT</a></li>
                            <li><a href="exit.php">LOGOUT</a></li>
                        </ul>
                    </div>
                    <i class="fa fa-bars" onclick="showmenu()"></i>

                </nav>
                <h1>Investo</h1>
                <h2>
                    The key is in not spending time, but in investing it!!!
                </h2>
            </section>
            <!-- About Investors -->
            <section>
                <!--<div class="r">
                    <div class="c1">
                        <h3>Investor1</h3>
                        <img src="inves.jpg" style="width:100%">
                        <p>Name: abc<br>Field:</p>
                    </div>
                     <div class="c1">
                        <h3>Investor2</h3>
                        <img src="inves.jpg" style="width:100%">
                        <p>Name: xyz<br>Field:</p>
                    </div>
                    <div class="c1">
                        <h3>Investor3</h3>
                        <img src="inves.jpg" style="width:100%">
                        <p>Name: pqr<br>Field:</p>
                    </div>
                    <div class="c1">
                        <h3>Investor4</h3>
                        <img src="inves.jpg" style="width:100%">
                        <p>Name: 123<br>Field:</p>
                    </div> 
                </div>-->
                <?php
                     $servername="localhost";
                     $username="root";
                     $password="";
                     $dbname="mini_project2";
                     
                     $conn=mysqli_connect($servername,$username,$password,$dbname);
                     
                     if($conn)
                     {
                         //echo "connection done";
                     }
                     else{
                         echo "Connection Failed".mysqli_connect_error();
                     }
                     error_reporting(0);
                     $query1="select * from investor";
                     $data1=mysqli_query($conn,$query1);
                     $i=1;
                     $ciphering = "AES-128-CTR";
                     $iv_length = openssl_cipher_iv_length($ciphering);
                     $options = 0;
                     $encryption_iv = '1234567891011121';
                     $encryption_key = "sakethkrishnamanoj";
                while($result=mysqli_fetch_assoc($data1)){
                    if($result['email']!=$_SESSION['email']){
                        $Inmail=$result['email'];
                        $encryption = openssl_encrypt($Inmail, $ciphering,
                        $encryption_key, $options, $encryption_iv);
                echo '<div class="r1">
                    <div class="c1">
                        <h3>Investor '; echo $i;echo '</h3>
                        <a href=';echo "'profiles2/pro2.php?email=$encryption'";echo '><img src="inves.jpg" style="width:100%"></a>
                        <p>Name: ';echo $result['name'];echo '<br>Field:';echo $result['field'];echo '</p>
                    </div>';
                    $i++;
                }
                }
                    //<!-- <div class="c1">
                        //<h3>Investor6</h3>
                        //<img src="inves.jpg" style="width:100%">
                      //  <p>Name: xyz1<br>Field:</p>
                    //</div>
                    //<div class="c1">
                        //<h3>Investor7</h3>
                        //<img src="inves.jpg" style="width:100%">
                      //  <p>Name: pqr1<br>Field:</p>
                    //</div>
                     //<div class="c1">
                        //<h3>Investor8</h3>
                      //  <img src="inves.jpg" style="width:100%">
                    //    <p>Name: 1234<br>Field:</p>
                  //  </div> --> 
                //</div>
                ?>
            </section>
            <!-- footer -->
            <section class="footer">
            <div class="foo">
                <h4>About Us</h4>
                <p>This website was developed to create a platform to connect both Entrepreneurs and Investors together</p>
                <div class="icons">
                    <i class="fa fa-facebook"></i>
                    <i class="fa fa-twitter"></i>
                    <i class="fa fa-instagram"></i>
                    <i class="fa fa-linkedin"></i>
                </div>
            </div>
            </section>
            <!-- Jvasscript for toggle menu -->
            <script>
                var nL = document.getElementById("nL");
                function showmenu(){
                    nL.style.right="0";
                }
                function hidemenu(){
                    nL.style.right="0";
                }
            </script>
    </body>
</html>