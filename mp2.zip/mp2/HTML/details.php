<?php
error_reporting(0);
$eemail=$_GET['email'];
$ciphering = "AES-128-CTR";
$options = 0;
$decryption_iv = '1234567891011121';
$decryption_key = "sakethkrishnamanoj";
$decryption=openssl_decrypt ($eemail, $ciphering, $decryption_key, $options, $decryption_iv);
//echo "Decrypted String: " . $decryption;
?>