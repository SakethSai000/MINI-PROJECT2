<?php
session_start();
if(!isset($_SESSION['logged']))
{
	header('Location: /mp2/HTML/Error.php');
}
    if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS']==='on'){
    $url="http://";
    }else{
    $url="http://";
    $url.=$_SERVER['HTTP_HOST'];
    $url.=$_SERVER['REQUEST_URI'];
    $url;
    }
$page=$url;
$sec="5";
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="refresh" content="<?php echo $sec; ?>" URL="
        <?php echo $page; ?>">
        <meta name="viewport" content="with=device-width, initial-scale=1.0">
        <meta charset="utf-8">

        <title>STARTUP-ANGELIVESTO</title>
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" integrity="sha384-jLKHWM3JRmfMU0A5x5AkjWkw/EYfGUAGagvnfryNV3F9VqM98XiIH7VBGVoxVSc7" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
        <!-- Home -->
            <section class="header">
                <!-- <img src="backgro.png" alt="Trulli" width="500" height="333"> -->
                <nav>
                    <a href="Index.php"><img src="logo.jpg"></a>
                    <div class="nav-links" id="nL">
                        <i class="fa fa-times" onclick="hidemenu()"></i>
                        <ul>
                            <li><a href="">HOME</a></li>
                            <li><a href="entreprenuer1.php">ENTREPRENEUR</a></li>
                            <li><a href="investor1.php">INVESTOR</a></li>
                            <li><a href="INFO/select.php">ABOUT</a></li>
                            <li><a href="exit.php">LOGOUT</a></li>
                        </ul>
                    </div>
                    <i class="fa fa-bars" onclick="showmenu()"></i>

                </nav>
                <div class="text-box">
                    <h1>Platform for Everyone</h1>
                    <p>Chase the vision, not the money<br>the money will end up following you.
                    </p>
                    <a href="investor1.php" class="hb">Visit our Investors</a>
                    <a href="entreprenuer1.php" class="hb">Visit our Entrepreneurs</a>
                </div>
            </section>


            <!-- recent feed -->
            <section class="rf">
                <h1>Recent Feeds</h1>
                <p>Recent connections at our website.</p>
                <div class="row">
                    <div class="rf-col">
                        <h3>Connection1</h3>
                        <p>abc1 just got a investment from xyz1</p>
                    </div>
                    <div class="rf-col">
                        <h3>Connection2</h3>
                        <p>abc2 just got a investment from xyz2</p>
                    </div>
                    <div class="rf-col">
                        <h3>Connection3</h3>
                        <p>abc3 just got a investment from xyz3</p>
                    </div>
                </div>
            </section>
            <section class="footer">
                <h4>About Us</h4>
                <p>This website was developed to create a platform to connect both Entrepreneurs and Investors together</p>
                <div class="icons">
                    <i class="fa fa-facebook"></i>
                    <i class="fa fa-twitter"></i>
                    <i class="fa fa-instagram"></i>
                    <i class="fa fa-linkedin"></i>
                </div>
            </section>
            <!-- Jvasscript for toggle menu -->
            <script>
                var nL = document.getElementById("nL");
                function showmenu(){
                    nL.style.right="0";
                }
                function hidemenu(){
                    nL.style.right="0";
                }
            </script>
    </body>
</html>